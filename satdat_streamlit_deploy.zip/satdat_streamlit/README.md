# 🌾 SatDat – Analisis Ketahanan Pangan Indonesia
## t-SNE + DBSCAN Dashboard

Dashboard interaktif untuk menganalisis ketahanan pangan 38 provinsi Indonesia menggunakan **DBSCAN** dan **t-SNE**.

---

## 🚀 Deploy ke Streamlit Community Cloud

### Langkah 1 – Siapkan Repository GitHub

1. Buat repository baru di [github.com](https://github.com) (misalnya: `satdat-dashboard`)
2. Upload **semua file** berikut ke repo tersebut:

```
satdat-dashboard/
├── app.py
├── requirements.txt
└── data/
    └── <file_excel_kamu>.xlsx   ← Wajib ada!
```

> **Penting:** Pastikan file Excel ada di folder `data/` di dalam repo.

### Langkah 2 – Deploy di Streamlit

1. Buka [share.streamlit.io](https://share.streamlit.io)
2. Login dengan akun GitHub kamu
3. Klik **"New app"**
4. Isi form:
   - **Repository:** `username/satdat-dashboard`
   - **Branch:** `main`
   - **Main file path:** `app.py`
5. Klik **"Deploy!"**

---

## 📁 Struktur File Data

File Excel harus memiliki kolom-kolom berikut (Sheet1):

| Kolom | Keterangan |
|-------|------------|
| `PROVINSI` | Nama provinsi |
| `IKP` | Indeks Ketahanan Pangan |
| `Produksi Padi` | Produksi padi (X1) |
| `produksi jagung` | Produksi jagung (X2) |
| `PDRB ADHB` | PDRB per kapita (X3) |
| `harga beras` | Harga beras (X4) |
| `akses sanitasi layak` | Akses sanitasi (X5) |
| `akses air minum layak` | Akses air minum (X6) |
| `Curah hujan (mm/hari)` | Curah hujan (X7) |
| `Kecepatan angin pada ketinggian 2 meter (m/s)` | Kecepatan angin (X8) |

---

## 🛠️ Jalankan Lokal

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

## 📊 Fitur Dashboard

| Halaman | Deskripsi |
|---------|-----------|
| 🏠 Beranda | Ringkasan & preview data |
| 📊 Eksplorasi Data | Distribusi, korelasi, ranking provinsi |
| 🔵 Klasterisasi DBSCAN | Hasil clustering + evaluasi metrics |
| 🎯 Visualisasi t-SNE | Reduksi dimensi 2D interaktif |
| 🔬 Analisis Gabungan | Profil klaster & radar chart |
| 📌 Karakteristik Klaster | Analisis 4 aspek per klaster |

**Mata Kuliah:** Pembelajaran Mesin | **Semester Genap 2025/2026**
